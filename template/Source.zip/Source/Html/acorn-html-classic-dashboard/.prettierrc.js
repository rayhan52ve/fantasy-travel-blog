module.exports = {
    "trailingComma": "all",
    "singleQuote": true,
    "printWidth": 160,
    "bracketSpacing": false,
    "tabWidth": 2,
    "semi": true,
    "arrowParens": "always",
    "htmlWhitespaceSensitivity": "ignore"
}